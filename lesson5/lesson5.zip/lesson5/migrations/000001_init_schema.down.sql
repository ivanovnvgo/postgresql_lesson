DROP TABLE groups;
DROP TABLE students;
DROP TABLE courses;
DROP TABLE grades;